﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
namespace MVCtravelmore.Controllers
{
    public class FlightsController : Controller
    {
        [Authorize]
        public IActionResult GetFlights()
        {
            return View();
        }
    }
}
