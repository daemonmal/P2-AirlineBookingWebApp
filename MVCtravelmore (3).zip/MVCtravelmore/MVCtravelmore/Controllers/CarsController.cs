﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
namespace RevatureAirLines.Controllers.MVC
{
    public class CarsController : Controller
    {
        [Authorize]
        public ActionResult GetCars()
        {
            return View();
        }
    }
}
