﻿using Microsoft.AspNetCore.Mvc;
using MVCtravelmore.Models;
using Microsoft.AspNetCore.Authorization;
namespace RevatureAirLines.Controllers.MVC
{
    public class HotelReservationsController : Controller
    {

        [Authorize]
        public ActionResult GetHReservations()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddHReservation(HReservations newReservation)
        {
            HReservations pObj = new HReservations();
            ViewBag.result = pObj.AddNewReservation(newReservation).Result;
            return View();
        }
    }
}
