﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MVCtravelmore.Models;

namespace RevatureAirLines.Controllers.MVC
{
    public class CarReservationsController : Controller
    {
        [Authorize]
        public ActionResult GetCReservations()
        {
            return View();
        }

        [HttpPost]
        
        public IActionResult AddCReservation(CReservations newReservation)
        {
            CReservations pObj = new CReservations();
            ViewBag.result = pObj.AddNewReservation(newReservation).Result;
            return View();
        }

    }
}
