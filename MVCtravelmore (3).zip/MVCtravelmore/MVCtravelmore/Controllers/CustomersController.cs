﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
namespace MVCtravelmore.Controllers
{
    public class CustomersController : Controller
    {
        [Authorize]
        public IActionResult GetCustomers()
        {
            return View();
        }
    }
}
