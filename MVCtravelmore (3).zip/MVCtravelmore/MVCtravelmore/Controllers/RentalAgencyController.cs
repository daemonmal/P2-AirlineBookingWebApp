﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
namespace RevatureAirLines.Controllers.MVC
{
    public class RentalAgencyController : Controller
    {

        [Authorize]
        public ActionResult GetAgency()
         {
             return View();
         }
        
    }
}
