﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace RevatureAirLines.Controllers.MVC
{
    public class HotelRoomsController : Controller
    {
        [Authorize]
        public ActionResult GetRooms()
        {
            return View();
        }
    }
}
