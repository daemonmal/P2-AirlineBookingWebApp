﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace MVCtravelmore.Models
{
    public class HReservations 
    {
        public int reservationId { get; set; }
        public int hotelId { get; set; }
        public int roomId { get; set; }
        public DateTime checkIn { get; set; }
        public DateTime checkOut { get; set; }
        public int hotelName { get; set; }
        public int hotelCity { get; set; }
        

        public async Task<string> AddNewReservation(HReservations newReservation)
        {
            string url = "https://localhost:7079/api/HotelReservations";

            var myContent = JsonConvert.SerializeObject(newReservation);
            var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
            var byteContent = new ByteArrayContent(buffer);
            byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            using (HttpClient client = new HttpClient())
            {
                using (HttpResponseMessage res = await client.PostAsync(url, byteContent))
                {
                    using (HttpContent content = res.Content)
                    {
                        string data = await content.ReadAsStringAsync();
                        if (data != null) { return "Reservation Added Successfully"; }
                    }
                }
            }
            return "please contact Admin ";


        }
    }
}
