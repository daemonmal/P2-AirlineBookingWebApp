﻿using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace MVCtravelmore.Models
{
    public class CReservations
    {
        public int reservationId { get; set; }
        public int agencyId { get; set; }
        public int carId { get; set; }
        public DateTime checkIn { get; set; }
        public DateTime checkOut { get; set; }
        public int agencyName { get; set; }
        public int agencyLocation { get; set; }

        public async Task<string> AddNewReservation(CReservations newReservation)
        {
            string url = "https://localhost:7079/api/CarReservations";

            var myContent = JsonConvert.SerializeObject(newReservation);
            var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
            var byteContent = new ByteArrayContent(buffer);
            byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            using (HttpClient client = new HttpClient())
            {
                using (HttpResponseMessage res = await client.PostAsync(url, byteContent))
                {
                    using (HttpContent content = res.Content)
                    {
                        string data = await content.ReadAsStringAsync();
                        if (data != null) { return "Reservation Added Successfully"; }
                    }
                }
            }
            return "please contact Admin ";


        }
    }
}
