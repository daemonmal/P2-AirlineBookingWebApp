﻿using Microsoft.AspNetCore.Mvc;

namespace RevatureAirLines.Controllers.MVC
{
    public class RentalAgencyController : Controller
    {
        
       
         public ActionResult GetAgency()
         {
             return View();
         }
        
    }
}
