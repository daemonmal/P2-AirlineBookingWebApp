﻿using Microsoft.AspNetCore.Mvc;
using MVCtravelmore.Models;

namespace RevatureAirLines.Controllers.MVC
{
    public class HotelReservationsController : Controller
    {
        
        public ActionResult GetHReservations()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddHReservation(HReservations newReservation)
        {
            HReservations pObj = new HReservations();
            ViewBag.result = pObj.AddNewReservation(newReservation).Result;
            return View();
        }
    }
}
