﻿using Microsoft.AspNetCore.Mvc;


namespace RevatureAirLines.Controllers.MVC
{
    public class HotelsController : Controller
    {
        
        public ActionResult GetHotels()
        {
            return View();
        }
    }
}
