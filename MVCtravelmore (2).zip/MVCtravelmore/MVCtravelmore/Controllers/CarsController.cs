﻿using Microsoft.AspNetCore.Mvc;

namespace RevatureAirLines.Controllers.MVC
{
    public class CarsController : Controller
    {
        
        public ActionResult GetCars()
        {
            return View();
        }
    }
}
