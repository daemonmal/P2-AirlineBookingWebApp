﻿using Microsoft.AspNetCore.Mvc;

namespace MVCtravelmore.Controllers
{
    public class CustomersController : Controller
    {
        public IActionResult GetCustomers()
        {
            return View();
        }
    }
}
