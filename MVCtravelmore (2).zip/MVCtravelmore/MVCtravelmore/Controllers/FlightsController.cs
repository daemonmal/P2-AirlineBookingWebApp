﻿using Microsoft.AspNetCore.Mvc;

namespace MVCtravelmore.Controllers
{
    public class FlightsController : Controller
    {
        public IActionResult GetFlights()
        {
            return View();
        }
    }
}
