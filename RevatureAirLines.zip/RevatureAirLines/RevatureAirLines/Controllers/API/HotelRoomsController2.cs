﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RevatureAirLines.Models;
namespace RevatureAirLines.Controllers.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class HotelRoomsController2 : ControllerBase
    {
        private readonly airlineDBContext _context = new airlineDBContext();

        // GET: api/HotelRooms
        [HttpGet]
        public async Task<ActionResult<IEnumerable<HotelRoom>>> GetHotelRoomsList()
        {
            var hotelRooms = new List<HotelRoom>();
            if (_context.HotelRooms == null)
            {
                return NotFound();
            }
            return Ok(_context.HotelRooms.ToList());
        }
    }
}
