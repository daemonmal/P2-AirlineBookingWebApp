﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RevatureAirLines.Models;
namespace RevatureAirLines.Controllers.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsController2 : ControllerBase
    {
        private readonly airlineDBContext _context = new airlineDBContext();

        // GET: api/Cars
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Car>>> GetCarsList()
        {
            var cars = new List<Car>();
            if (_context.Cars == null)
            {
                return NotFound();
            }
            return await _context.Cars.ToListAsync();
        }
    }
}
