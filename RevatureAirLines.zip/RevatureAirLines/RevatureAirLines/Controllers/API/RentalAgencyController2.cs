﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RevatureAirLines.Models;

namespace RevatureAirLines.Controllers.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class RentalAgencyController2 : ControllerBase
    {
        private readonly airlineDBContext _context = new airlineDBContext();
        public IActionResult GetAgency()
        {
            return Ok(_context.RentalAgencies.ToList());

        }
    }
}
