﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RevatureAirLines.Models;

namespace RevatureAirLines.Controllers.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class HotelsController2 : ControllerBase
    {
        private readonly airlineDBContext _context = new airlineDBContext();

        // GET: api/Hotels
        //[HttpGet]
        //public async Task<ActionResult<IEnumerable<Hotel>>> GetHotelsList()
        //{

        //    if (_context.Hotels == null)
        //    {
        //        return NotFound();
        //    }
        //    return await _context.Hotels.ToListAsync();
        //}
        public IActionResult GetHotels()
        {
            return Ok(_context.Hotels.ToList());

        }

    }
}
