﻿using Microsoft.AspNetCore.Mvc;
using RevatureAirLines.Models;

namespace RevatureAirLines.Controllers.MVC
{
    public class RentalAgencyController : Controller
    {
        
        private readonly airlineDBContext _context = new airlineDBContext();
         public ActionResult GetHotels()
         {
             return View(_context.RentalAgencies.ToList());
         }
        
    }
}
