﻿using Microsoft.AspNetCore.Mvc;
using RevatureAirLines.Models;

namespace RevatureAirLines.Controllers.MVC
{
    public class HotelReservationsController : Controller
    {
        private readonly airlineDBContext _context = new airlineDBContext();
        public ActionResult GetHReservations()
        {
            return View(_context.HotelReservations.ToList());
        }
    }
}
