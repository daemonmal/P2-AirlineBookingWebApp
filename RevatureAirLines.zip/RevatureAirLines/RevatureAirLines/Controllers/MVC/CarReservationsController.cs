﻿using Microsoft.AspNetCore.Mvc;
using RevatureAirLines.Models;

namespace RevatureAirLines.Controllers.MVC
{
    public class CarReservationsController : Controller
    {
        private readonly airlineDBContext _context = new airlineDBContext();
        public ActionResult GetCReservations()
        {
            return View(_context.CarReservations.ToList());
        }
    }
}
