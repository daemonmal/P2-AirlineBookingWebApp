﻿using Microsoft.AspNetCore.Mvc;
using RevatureAirLines.Models;

namespace RevatureAirLines.Controllers.MVC
{
    public class HotelRoomsController : Controller
    {
        private readonly airlineDBContext _context = new airlineDBContext();
        public ActionResult GetRooms()
        {
            return View(_context.HotelRooms.ToList());
        }
    }
}
