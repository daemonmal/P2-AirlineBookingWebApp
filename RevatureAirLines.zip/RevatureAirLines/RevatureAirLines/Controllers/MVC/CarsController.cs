﻿using Microsoft.AspNetCore.Mvc;
using RevatureAirLines.Models;

namespace RevatureAirLines.Controllers.MVC
{
    public class CarsController : Controller
    {
        private readonly airlineDBContext _context = new airlineDBContext();
        public ActionResult GetCars()
        {
            return View(_context.Cars.ToList());
        }
    }
}
