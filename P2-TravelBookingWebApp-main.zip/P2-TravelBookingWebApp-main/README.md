# P2-TravelBookingWebApp
 Fullstack web app using C# .NET API, MVC, SQL Server on Azure, Entity Framework, Angular, JS, Jquery, and Bootstrap
