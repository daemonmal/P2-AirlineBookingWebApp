﻿using System;
using System.Collections.Generic;

namespace P2_TravelBookingAppAPI.Models.EF
{
    public partial class Flight
    {
        public Flight()
        {
            Customers = new HashSet<Customer>();
        }

        public int flightId { get; set; }
        public string? fromCity { get; set; }
        public string? toCity { get; set; }             
        public DateTime? takeoff { get; set; }
        public DateTime? landingtime { get; set; }
        public double? price { get; set; }

        public virtual ICollection<Customer> Customers { get; set; }
    }
}
