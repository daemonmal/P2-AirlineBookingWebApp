﻿using Microsoft.AspNetCore.Mvc;


namespace RevatureAirLines.Controllers.MVC
{
    public class HotelRoomsController : Controller
    {
        
        public ActionResult GetRooms()
        {
            return View();
        }
    }
}
